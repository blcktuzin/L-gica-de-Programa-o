import java.util.Scanner;

public class ati_02 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("digite o primeiro numero");
        double n1 = sc.nextDouble();
        double resposta = n1 * 2;
        System.out.println("seu numero é " + resposta);
    }
}

