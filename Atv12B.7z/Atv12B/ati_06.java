import java.util.Scanner;

public class ati_06 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Qual a temperatura: ");
        double temp = sc.nextDouble();

        double temperatura = (temp * 9/5) + 32;

        System.out.printf("a temperatura é de: " + temperatura);
    }
}
