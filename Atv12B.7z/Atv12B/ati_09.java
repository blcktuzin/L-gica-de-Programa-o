import java.util.Scanner;

public class ati_09 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite a idade em anos: ");
        int idadeAnos = scanner.nextInt();

        int idadeMeses = idadeAnos * 12;

        System.out.println("A idade em meses é: " + idadeMeses);

        scanner.close();
    }
}
