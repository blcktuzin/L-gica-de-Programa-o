import java.util.Scanner;

public class ati_04 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.printf("qual é o valor da base do triangulo");
        double n1 = sc.nextDouble();
        System.out.printf("qual é o valor da altura do triangulo");
        double n2 = sc.nextDouble();
        double resposta = n1 * n2;
        System.out.printf("o valor da area do triangulo " + resposta);
    }
}
