import java.util.Scanner;

public class ati_08 {
        public static void main(String[] args) {
            Scanner sc = new Scanner(System.in);

            System.out.print("Digite o primeiro número: ");
            int num1 = sc.nextInt();

            System.out.print("Digite o segundo número: ");
            int num2 = sc.nextInt();

            if (num2 != 0) {
                int quociente = num1 / num2;
                int resto = num1 % num2;

                System.out.println("Resultado da divisão inteira: " + quociente);
                System.out.println("Resto da divisão: " + resto);
            } else {
                System.out.println("Erro: Divisão por zero não é permitida.");
            }
        }
}
