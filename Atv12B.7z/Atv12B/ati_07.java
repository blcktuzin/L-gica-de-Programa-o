import java.util.Scanner;

public class ati_07 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.printf("qual é a quantidade de dias ");
        double day = sc.nextDouble();

        double hrs = day * 24;
        System.out.printf("a quantidade de dias é: " + hrs);

        }
    }

