import java.util.Scanner;

public class ati_03 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.printf("digite o valor do raio");
        double n1 = sc.nextDouble();
        double resposta = 3.14 * (n1 * n1);
        System.out.println("a area do circulo é " + resposta);
    }
}
