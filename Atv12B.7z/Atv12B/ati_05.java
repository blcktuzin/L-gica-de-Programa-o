import java.util.Scanner;

public class ati_05 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Qual o valor do salário: ");
        double salario = sc.nextDouble();

        double aumento = salario * 0.10;
        double novoSalario = salario + aumento;

        System.out.printf("O aumento é de: R$ %.2f%n", aumento);
        System.out.printf("O novo salário é: R$ %.2f%n", novoSalario);
    }
}
