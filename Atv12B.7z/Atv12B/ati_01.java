import java.util.Scanner;

public class ati_01 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.printf("escreva o numero primeiro numero inteiro");
        int n1 = sc.nextInt();
        System.out.printf("escreva o numero segundo numero inteiro");
        int n2 = sc.nextInt();
        int resposta = n1 + n2;
        System.out.println("seu resultado é " + resposta);
    }
}
